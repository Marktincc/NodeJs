var colors = require('colors');
const inquirer = require('inquirer');
var prompt = require('prompt');
const {suma} = require('./module1');

const preguntas = [
    {
        type: 'list',
        name: 'options',
        message: 'que quieres hacer?',
        choices: [
            {
                value: '1',
                name: '1 SUMA',
            },
            {
                value: '2',
                name: '2 listar tareas',
            },
            {
                value: '3',
                name: '3 borrar tarea',
            },
            {
                value: '0',
                name: '0 salir',
            }
        ]
    }
]



const menu = () => {

    console.log(`${'°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°'.green}`);
    console.log(`${'           First Application'.blue}`);
    console.log(`${'°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°'.green}`);

    inquirer.prompt(preguntas).then(({options}) => {
        console.log(options);
        switch (options) {
            case '1':
                prompt.start();
                const answer = prompt.get(['value1','value2'],function(err,result){
                    if(err){
                        console.error(err);

                    }else{
                        suma(result.value1, result.value2);
                    }
                });
                
                suma(answer.value1, answer.value2);
                break;
            default:
                break;
        }
    })
}




module.exports = {
    menu
};
