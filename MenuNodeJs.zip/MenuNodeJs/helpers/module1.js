function suma(valor1, valor2){
  valor1 = parseInt(valor1);
  valor2 = parseInt(valor2);
  console.log(valor1 + valor2);
}

module.exports = {
  suma
};