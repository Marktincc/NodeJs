const { menu } = require('./helpers/menu');



const principal = () => {
    menu();
}

principal();
